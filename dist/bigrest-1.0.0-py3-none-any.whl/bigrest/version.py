"""File with version and history information."""

__version__ = '1.0.0'

"""
History Information:
1.0.0
    First Version
"""
